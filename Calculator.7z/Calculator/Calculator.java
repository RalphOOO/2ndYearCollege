import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Calculator extends JFrame{
    JLabel Operand1 = new JLabel();
    JLabel Operator = new JLabel();
    JLabel Operand2 = new JLabel();
    JLabel Result   = new JLabel();
    
    JButton Calculate = new JButton();
    JButton Exit = new JButton();
    
    JTextField Ope1 = new JTextField();
    JTextField Oper = new JTextField();
    JTextField Ope2 = new JTextField();
    JTextField Res  = new JTextField();
    
public Calculator(){
setTitle("Simple Calculator");

getContentPane().setLayout(new GridBagLayout());

GridBagConstraints gridConstraints = new GridBagConstraints();

Operand1.setText("Operand 1:");
gridConstraints.gridx=0;
gridConstraints.gridy=0;
getContentPane().add(Operand1,gridConstraints);

Operator.setText("Operator:");
gridConstraints.gridx=0;
gridConstraints.gridy=1;
getContentPane().add(Operator,gridConstraints);

Operand2.setText("Operand 2:");
gridConstraints.gridx=0;
gridConstraints.gridy=2;
getContentPane().add(Operand2,gridConstraints);

Result.setText("Result:");
gridConstraints.gridx=0;
gridConstraints.gridy=3;
getContentPane().add(Result,gridConstraints);

Calculate.setText("Calculate");
gridConstraints.gridx=0;
gridConstraints.gridy=4;
getContentPane().add(Calculate,gridConstraints);

Calculate.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
CalculateAction(e);
}
});

Ope1.setText("");
gridConstraints.gridx=1;
gridConstraints.gridy=0;
Ope1.setColumns(6);
getContentPane().add(Ope1,gridConstraints);

Oper.setText("");
gridConstraints.gridx=1;
gridConstraints.gridy=1;
Oper.setColumns(2);
getContentPane().add(Oper,gridConstraints);

Ope2.setText("");
gridConstraints.gridx=1;
gridConstraints.gridy=2;
Ope2.setColumns(6);
getContentPane().add(Ope2,gridConstraints);

Res.setText("");
gridConstraints.gridx=1;
gridConstraints.gridy=3;
Res.setColumns(6);
getContentPane().add(Res,gridConstraints);

Exit.setText("Exit");
gridConstraints.gridx=1;
gridConstraints.gridy=4;
getContentPane().add(Exit,gridConstraints);

Exit.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
ExitAction(e);
}
});

pack();
}

private void CalculateAction(ActionEvent e){
double Op1=Double.parseDouble(Ope1.getText());
double Op2=Double.parseDouble(Ope2.getText());
String Opr=Oper.getText();
if (Opr == "+"){
    double Result = Op1 + Op2;
    String ans=Double.toString(Result);
    Res.setText(ans);  
}

if (Opr == "-"){
    double Result = Op1 - Op2;
    String ans=Double.toString(Result);
    Res.setText(ans);
}

if (Opr == "*"){
    double Result = Op1 * Op2;
    String ans=Double.toString(Result);
    Res.setText(ans);
}
 
if (Opr == "/"){
    double Result = Op1 / Op2;
    String ans=Double.toString(Result);
    Res.setText(ans);
}

}

private void ExitAction(ActionEvent e){
JFrame f;
f = new JFrame();
JOptionPane.showMessageDialog(f,"Byeeee");
}

public static void main(String [] args){
  new Calculator().show();  
}
}
