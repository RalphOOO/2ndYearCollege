public class inheritanceTest
{
    public inheritanceTest()
    {
        Dog Dog1 = new Dog();
        Dog1.color = "black";
        Dog1.numLegs = "4";
        Dog1.dogName = "Jorbok";
        Dog1.showInfo();
    }
    
  
}