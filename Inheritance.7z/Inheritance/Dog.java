public class Dog extends animal
{
    String dogName;
    
    public Dog() 
    {
        
    }
    
    public String dogName() {
        return dogName;
    }
    
    public void dogName(String dogName) {
        this.dogName = dogName;
    }
    
    public Dog(String numLegs, String Color )
    {
        super( numLegs, Color);
        this.dogName("Jorbok");
        
    }
    
    public void showInfo()
    {
        System.out.println("My dog's name is " + dogName + " he has "+ numLegs+" legs");
    }
}