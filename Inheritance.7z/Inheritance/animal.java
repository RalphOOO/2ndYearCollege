public class animal
{
    String color;
    String numLegs;
    
    public animal() 
    {
        
    }
    
    public animal(String color,String numLegs) 
    {
        this.color = color;
        this.numLegs = numLegs;
        
    }

    public String color() {
        return color;
    }
    
    public String numLegs() {
        return numLegs;
    }
    
    public void color(String color) {
        this.color = color;
    }
    
    public void numLegs(String numLegs) {
        this.numLegs = numLegs;
    }
    
    public void showInfo()
    {
        System.out.println(color);
        System.out.println(numLegs);
    }
}